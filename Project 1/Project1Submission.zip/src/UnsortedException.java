public class UnsortedException extends Exception
{
	public UnsortedException(String message)
	{
		super(message);
	}
}
